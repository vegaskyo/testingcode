package org.apache.hop.www.auth;

import com.nimbusds.oauth2.sdk.TokenIntrospectionRequest;
import com.nimbusds.oauth2.sdk.TokenIntrospectionResponse;
import com.nimbusds.oauth2.sdk.TokenIntrospectionSuccessResponse;
import com.nimbusds.oauth2.sdk.auth.ClientSecretBasic;
import com.nimbusds.oauth2.sdk.auth.Secret;
import com.nimbusds.oauth2.sdk.http.HTTPResponse;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.oauth2.sdk.token.BearerAccessToken;
import java.util.Map;
import org.pac4j.core.context.WebContext;
import org.pac4j.core.context.session.SessionStore;
import org.pac4j.core.credentials.Credentials;
import org.pac4j.core.credentials.TokenCredentials;
import org.pac4j.core.credentials.authenticator.Authenticator;
import org.pac4j.core.exception.CredentialsException;
import org.pac4j.core.profile.CommonProfile;
import org.pac4j.oidc.config.KeycloakOidcConfiguration;

public class KeycloakTokenAuthenticator implements Authenticator {

    private final KeycloakOidcConfiguration config;

    public KeycloakTokenAuthenticator(KeycloakOidcConfiguration config) {
        this.config = config;
    }

    @Override
    public void validate(Credentials credentials, WebContext context, SessionStore sessionStore) {
        if (!(credentials instanceof TokenCredentials)) {
            throw new CredentialsException("Unsupported credentials type");
        }
        TokenCredentials tokenCredentials = (TokenCredentials) credentials;
        String accessToken = tokenCredentials.getToken();

        // 1) Build an introspection request
        String introspectEndpoint =
                config.getBaseUri()
                        + "/realms/"
                        + config.getRealm()
                        + "/protocol/openid-connect/token/introspect";

        // The token introspection request with client_secret_basic auth:
        ClientSecretBasic clientAuth =
                new ClientSecretBasic(new ClientID(config.getClientId()), new Secret(config.getSecret()));
        //    System.out.println("Secret: " + config.getSecret());
        TokenIntrospectionRequest request =
                new TokenIntrospectionRequest(
                        java.net.URI.create(introspectEndpoint),
                        clientAuth,
                        new BearerAccessToken(accessToken));

        // 2) Execute introspection call
        TokenIntrospectionResponse response;
        try {
            HTTPResponse httpResponse = request.toHTTPRequest().send();
            response = TokenIntrospectionResponse.parse(httpResponse);
        } catch (Exception e) {
            throw new CredentialsException("Keycloak introspection request failed", e);
        }

        // 3) Check if the token is active
        if (!response.toSuccessResponse().indicatesSuccess()) {
            throw new CredentialsException("Token introspection indicates failure");
        }
        TokenIntrospectionSuccessResponse success = response.toSuccessResponse();
        System.out.println("Token is active: " + success.isActive());
        if (!success.isActive()) {
            throw new CredentialsException("Token is not active, invalid or expired");
        }

        // 4) Build a user profile with info from Keycloak
        CommonProfile profile = new CommonProfile();
        //    profile.setId(success.getUsername() != null ? success.getUsername() : "unknown");
        //        System.out.println("Username: " + success.getUsername());
        //        // You can set more attributes, e.g.
        //        profile.addAttribute("scope", success.getScope());
        //        System.out.println("Scope: " + success.getScope());
        //        profile.addAttribute("sub", success.getSubject());
        //        System.out.println("Subject: " + success.getSubject());
        //        profile.addAttribute("preferred_username",
        //     success.getStringParameter("preferred_username"));
        //        System.out.println("Preferred username: " +
        //     success.getStringParameter("preferred_username"));

        Map<String, Object> claims = success.toJSONObject();
        for (Map.Entry<String, Object> entry : claims.entrySet()) {
            profile.addAttribute(entry.getKey(), entry.getValue());
        }
        // etc.

        // 5) Finally, attach the user profile to the credentials
        tokenCredentials.setUserProfile(profile);
    }
}
