package org.apache.hop.www.auth;

import com.nimbusds.oauth2.sdk.auth.ClientAuthenticationMethod;
import org.pac4j.core.client.Clients;
import org.pac4j.core.config.Config;
import org.pac4j.core.config.ConfigFactory;
import org.pac4j.http.client.direct.DirectBearerAuthClient;
import org.pac4j.jee.context.session.JEESessionStore;
import org.pac4j.oidc.client.KeycloakOidcClient;
import org.pac4j.oidc.config.KeycloakOidcConfiguration;

public class Pac4jConfigFactory implements ConfigFactory {

    public Pac4jConfigFactory() {}

    public static Config createPac4jConfig() {
        return new Pac4jConfigFactory().build();
    }

    private static final String HOP_CLIENT_ID = System.getenv("HOP_CLIENT_ID");
    private static final String HOP_CLIENT_SECRET = System.getenv("HOP_CLIENT_SECRET");
    private static final String KEYCLOAK_BASE_URI = System.getenv("KEYCLOAK_BASE_URI");
    private static final String HOP_REALM = System.getenv("HOP_REALM");
    private static final String CALLBACK_URL = System.getenv("CALLBACK_URL");

    private static final String DEFAULT_CLIENT_NAME = "OidcClient";

    @Override
    public Config build(Object... parameters) {
        KeycloakOidcConfiguration keycloakOidcConfiguration = getKeycloakOidcConfiguration();

        KeycloakOidcClient oidcClient = new KeycloakOidcClient(keycloakOidcConfiguration);
        oidcClient.setName((String) (parameters.length > 0 ? parameters[0] : DEFAULT_CLIENT_NAME));

        // 2) Direct bearer client for Authorization: Bearer <token>.
        //    We'll attach our custom KeycloakTokenAuthenticator below.

        DirectBearerAuthClient bearerClient =
                new DirectBearerAuthClient(new KeycloakTokenAuthenticator(keycloakOidcConfiguration));
        bearerClient.setName("BearerClient");

        // Set up clients with the OIDC client
        Clients clients = new Clients(CALLBACK_URL, oidcClient, bearerClient);

        // Create the Pac4j configuration
        Config config = new Config(clients);
        config.setSessionStore(JEESessionStore.INSTANCE);

        return config;
    }

    private static KeycloakOidcConfiguration getKeycloakOidcConfiguration() {
        KeycloakOidcConfiguration keycloakOidcConfiguration = new KeycloakOidcConfiguration();
        keycloakOidcConfiguration.setRealm(HOP_REALM);
        keycloakOidcConfiguration.setClientId(HOP_CLIENT_ID);
        keycloakOidcConfiguration.setSecret(HOP_CLIENT_SECRET);
        keycloakOidcConfiguration.setBaseUri(KEYCLOAK_BASE_URI);
        keycloakOidcConfiguration.setUseNonce(true);
        keycloakOidcConfiguration.setClientAuthenticationMethod(
                ClientAuthenticationMethod.CLIENT_SECRET_BASIC);
        keycloakOidcConfiguration.setWithState(true);
        keycloakOidcConfiguration.setResponseType("code");
        keycloakOidcConfiguration.setDisablePkce(false);
        keycloakOidcConfiguration.setScope("openid profile email");
        return keycloakOidcConfiguration;
    }
}
